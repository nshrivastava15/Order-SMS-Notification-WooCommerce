function userName(){
      var x = sessionStorage.getItem("userid");
  document.getElementById("usersid").innerHTML = x;
}

function signout(){
	window.location.replace("../login.html");
}



//drag and dropbtn<script>
function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  if(is_safe(data))
	{
		ev.target.value = ev.target.value +" " + data;
		if(data.charAt(0) == 's' || data.charAt(0) == 'S')
			document.getElementById("source").value  = document.getElementById("source").value  + " " + data;
		else if(data.charAt(0) == 'd' || data.charAt(0) == 'D')
			document.getElementById("destination").value  = document.getElementById("destination").value  + " " +  data;
	}
	else
	{
		alert("This destination field is already present");
	}
  
}


function is_safe(data)
{
	if(data.charAt(0) == 'd' || data.charAt(0) == 'D')
	{
		var res = document.getElementById("destination").value.split(" ");
		for(var i = 0; i<res.length; i++)
		{
			if(data == res[i])
				return  false;
		}
		
		var table = document.getElementById("mapping_table");
		var length = document.getElementById("mapping_table").getElementsByTagName("tr").length;
		for(var i = 1; i<length; i++)
		{
			var a = table.rows[i].cells[5].innerHTML.split();
			for(var j = 0; j<a.length; j++)
			{
				if(data.trim() == a[j].trim())
					return  false;
			}
		}
		
		return true;
	}
	else
		return true;
}

function reset()
{
	document.getElementById("logical_statment").value = "";
	document.getElementById("comments").value = "";
	document.getElementById("source").value = "";
	document.getElementById("destination").value = "";
}

window.onload = function fun(){
document.getElementById("sheet_1_button").style.backgroundColor = "#034588";
document.getElementById("sheet_1_button").style.color = "white";
}

function add(){

	var rows = document.getElementById("mapping_table").getElementsByTagName("tr").length;

	var table = document.getElementById("mapping_table");
	var row = table.insertRow(-1);
	var cell0 = row.insertCell(0)
	var cell1 = row.insertCell(1);
	var cell2 = row.insertCell(2);
	var cell3 = row.insertCell(3)
	var cell4 = row.insertCell(4);
	var cell5 = row.insertCell(5);
	var cell6 = row.insertCell(6)
	var cell7 = row.insertCell(7);
	var cell8 = row.insertCell(8);
	var cell9 = row.insertCell(9);
	var cell10 = row.insertCell(10);
	var cell11 = row.insertCell(11);
	
	cell0.innerHTML = rows;
	cell1.innerHTML = document.getElementById("source").value;
	cell2.innerHTML = "sample";
	cell3.innerHTML = "sample";
	cell4.innerHTML = "sample";
	cell5.innerHTML = document.getElementById("destination").value;
	cell6.innerHTML = "sample";
	cell7.innerHTML = document.getElementById("logical_statment").value;
	cell8.innerHTML = document.getElementById("comments").value;
	cell9.innerHTML = "sample";
	cell10.innerHTML = "sample";
	cell11.innerHTML =  '<button onclick="delete_row(this)" > DELETE </button>';
	reset();
	
}
	function  delete_row(element) {
    /*alert("row" + element.parentNode.parentNode.rowIndex + 
    " - column" + element.parentNode.cellIndex);*/
	var row = element.parentNode.parentNode.rowIndex; 
	var table = document.getElementById("mapping_table");
	table.deleteRow(row);
	refresh_sl_no();
	}
	
	function refresh_sl_no()
	{
		var table = document.getElementById("mapping_table");
		var length = document.getElementById("mapping_table").getElementsByTagName("tr").length;
		for(var i = 1; i<length; i++)
		{
			table.rows[i].cells[0].innerHTML = i;
		}
	}
	
	function append(e)
	{
	var data = e.id;
	 if(is_safe(data))
		{
			document.getElementById("logical_statment").value  = document.getElementById("logical_statment").value  + " " + data;
			if(data.charAt(0) == 's' || data.charAt(0) == 'S')
				document.getElementById("source").value  = document.getElementById("source").value  + " " + data;
			else if(data.charAt(0) == 'd' || data.charAt(0) == 'D')
				document.getElementById("destination").value  = document.getElementById("destination").value  + " " +  data;
		}
		else
		{
			alert("This destination field is already present");
		}
	}
	
	
	function expand_colapse(id)
	{
		var cn = document.getElementById(id).className;
		//alert(cn);
		if(cn == "display")
		{
			document.getElementById(id + "_button").innerHTML = "+";
			document.getElementById(id).className = "dont_display";
		}
		else
		{
			document.getElementById(id + "_button").innerHTML = "-";
			document.getElementById(id).className = "display";
		}
	}
	