function userName(){
      var x = sessionStorage.getItem("userid");
  document.getElementById("usersid").innerHTML = x;
}

function signout(){
	window.location.replace("../login.html");
}