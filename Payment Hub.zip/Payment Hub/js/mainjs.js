// Hide submenus
$('#body-row .collapse').collapse('hide'); 

// Collapse/Expand icon
$('#collapse-icon').addClass('fa-angle-double-left'); 

// Collapse click
$('[data-toggle=sidebar-colapse]').click(function() {
    SidebarCollapse();
});

function SidebarCollapse () {
    $('.menu-collapsed').toggleClass('d-none');
    $('.sidebar-submenu').toggleClass('d-none');
    $('.submenu-icon').toggleClass('d-none');
    $('#sidebar-container').toggleClass('sidebar-expanded sidebar-collapsed');
    
    // Treating d-flex/d-none on separators with title
    var SeparatorTitle = $('.sidebar-separator-title');
    if ( SeparatorTitle.hasClass('d-flex') ) {
        SeparatorTitle.removeClass('d-flex');
    } else {
        SeparatorTitle.addClass('d-flex');
    }
    
    // Collapse/Expand icon
    $('#collapse-icon').toggleClass('fa-angle-double-left fa-angle-double-right');
}

function regionName(){
      var x = sessionStorage.getItem("region");
  document.getElementById("regName").innerHTML = x;
}

function passwordChange() {
	document.getElementById('div1').style.display="none";
	document.getElementById('div2').style.display="block";	
}

function savePassword() {
	alert('Password Changed Successfully');
	document.getElementById('div1').style.display="block";
	document.getElementById('div2').style.display="none";
return true;	
}

function cancelPassword() {
	document.getElementById('div1').style.display="block";
	document.getElementById('div2').style.display="none";
}

function changePassword(){
    alert('password changed successfully');
}

$("#checkAll").click(function () {
    $(".check").prop('checked', $(this).prop('checked'));
});


function changeRegion() {
  var x = document.getElementById("selectRegion").value;
  sessionStorage.setItem("region",x);
  window.location.reload();
}
function defaultChange() {
    document.getElementById('changeDefault').style.display="none";
    document.getElementById('defaultSet').style.display="block";  
}

//country dropdown

var mealsByCategory = {
    EMEA: ["UAE"],
    APAC: ["India", "Japan", "China", "Thailand", "Cambodia", "Hawaii", "Nepal", "Philippines", "Malaysia", "Myanmar", "Laos", "Australia", "New Zealand", "Brunei"],
    LATAM:["Austria "],
	NAM:  ["Belize", "Costa Rica", "El Salvador", "Guatemala", "Honduras", "Mexico", "Panama"],
}
	
    function changecat(value) {
		if (value.length == 0) document.getElementById("countryModalBody").innerHTML = "<tr><td>1</td></tr>";
        else {
            var catOptions = "";
            for (categoryId in mealsByCategory[value]) {
				
                catOptions += "<tr><td><a href= '#'>"+ mealsByCategory[value][categoryId] +"</a></td></tr>";
            }
			$("#countrymodal").modal();
            document.getElementById("countryModalBody").innerHTML = catOptions;
        }
    }

//country dropdown ends

function implementationSelect() {
	$("#myModal1").modal();
}